import React from "react";
import NavBar from '../components/NavBar';
import HomeImg from '../images/interview.svg';

export const Home = () => {
    return (
        <>
            <NavBar/>
            <div className="container-fluid mt-5 pt-5 px-5">
                <div className="row">
                    <div className="col pt-5 headingCol">
                        <p className="heading">Interview <br/> mastery, <br/> made easy.</p>
                        <p className="fs-3">Never fear an interview again: <br/> Prepare
                            for success with our <br/>comprehensive
                            and versatile <br/> interview simulator</p>
                        <button type="button" className="btn btn-primary">Get Started</button>
                    </div>
                    <div className="col">
                    <img src={HomeImg} className="img-fluid" alt=""/>
                    </div>
                </div>
            </div>
        </>
    )
}
